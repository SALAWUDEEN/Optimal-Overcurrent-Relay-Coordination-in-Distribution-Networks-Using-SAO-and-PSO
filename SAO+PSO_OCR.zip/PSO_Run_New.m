clc;
clear;
close all;

%% Problem Definition
Q=input('Press One (1) to Run My PSO: \n Press Two (2) to Run Standard PSO using Kheshti data:\n := ');
CostFunction=@(x) MyCost15(x);        % Cost Function

global Ifp TMS PS CTr a b
nVar=1;            % Number of Decision Variables

VarSize=[1 nVar];   % Size of Decision Variables Matrix

VarMin=0.1;         %Lower Bound of TMS 
VarMax= 1.1;        %Upper Bound of TMS 
VMin=0.5;           %Lower Limit for PS 
VMax=2.5;           %Upper Limit for PS
%% PSO Parameters

MaxIt=100;      % Maximum Number of Iterations

nPop=50;        % Population Size (Swarm Size)

% PSO Parameters
w=1;            % Inertia Weight
wmax=0.9;       %Maximum Inertial weight
wmin=0.4;       %Minimum Inertial weight
wdamp=0.99;     % Inertia Weight Damping Ratio
c1=2;         % Personal Learning Coefficient
c2=2.0;         % Global Learning Coefficient
% If you would like to use Constriction Coefficients for PSO,
% uncomment the following block and comment the above set of parameters.
% Constriction Coefficients
% phi1=2.05;
% phi2=2.05;
% phi=phi1+phi2;
% chi=2/(phi-2+sqrt(phi^2-4*phi));
% w=chi;          % Inertia Weight
% wdamp=1;        % Inertia Weight Damping Ratio
% c1=chi*phi1;    % Personal Learning Coefficient
% c2=chi*phi2;    % Global Learning Coefficient
% Velocity Limits
VelMax=0.1*(VarMax-VarMin);
VelMin=-VelMax;

%% Initialization

empty_particle.Position=[];
empty_particle.Cost=[];
empty_particle.Velocity=[];
empty_particle.Best.Position=[];
empty_particle.Best.Cost=[];

particle=repmat(empty_particle,nPop,1);

GlobalBest.Cost=inf;
Position1=VarMin+(0.6-VarMin)*rand(nPop,1);
Position2=VMin+(0.85-VMin)*rand(nPop,1);
Pop_Particle=[Position1 Position2];
tic
for i=1:nPop
    
    % Initialize Position
%     particle(i).Position=unifrnd(VarMin,VarMax,VarSize);
    Position1=unifrnd(VarMin,VarMax,VarSize);
    Position2=unifrnd(VMin,VMax,VarSize);
     particle(i).Position=[Position1,Position2];
    % Initialize Velocity
    particle(i).Velocity=zeros(VarSize);
    % Evaluation
    particle(i).Cost=CostFunction(particle(i).Position);
    
    % Update Personal Best
    particle(i).Best.Position=particle(i).Position;
    particle(i).Best.Cost=particle(i).Cost;
    
    % Update Global Best
    if particle(i).Best.Cost<GlobalBest.Cost
        
        GlobalBest=particle(i).Best;
        
    end
    
end
BestCost=zeros(MaxIt,1);

%% PSO Main Loop
Pop=[];
for it=1:MaxIt
    
    for i=1:nPop
        lamda=((MaxIt-it)/MaxIt)^(nPop);
        if Q==1
        w=wmin+(wmax-wmin)*lamda^(it-1);
        alpha=wmax+wmin;
        elseif Q==2
            w=wmax-((wmax-wmin)/MaxIt)*it;
            alpha=wmax+1.4*wmin;
        else
            'Sorry the Input can Either be One or Two'
            alpha=0;
            return
        end
        % Update Velocity
        particle(i).Velocity = w*particle(i).Velocity ...
            +c1*rand(VarSize).*(particle(i).Best.Position-particle(i).Position) ...
            +c2*rand(VarSize).*(GlobalBest.Position-particle(i).Position);
        
        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity,VelMin);
        particle(i).Velocity = min(particle(i).Velocity,VelMax);
        
        % Update Position
        particle(i).Position = particle(i).Position + particle(i).Velocity;
        
        % Velocity Mirror Effect
        IsOutside=(particle(i).Position<VarMin | particle(i).Position>VarMax);
        particle(i).Velocity(IsOutside)=-particle(i).Velocity(IsOutside);
        
        % Apply Position Limits
        particle(i).Position = max(particle(i).Position,VarMin);
        particle(i).Position = min(particle(i).Position,VarMax);
        
        % Evaluation
        particle(i).Cost = CostFunction(particle(i).Position);
        
        % Update Personal Best
        if particle(i).Cost<particle(i).Best.Cost
            
            particle(i).Best.Position=particle(i).Position;
            particle(i).Best.Cost=particle(i).Cost;
            
            % Update Global Best
            if particle(i).Best.Cost<GlobalBest.Cost
                
                GlobalBest=particle(i).Best;
                
            end
            
        end
%         Pop(i)=particle(i).Best
    end
  
   BestCost(it)=GlobalBest.Cost*alpha;
   
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))])
    
    w=w*wdamp;
    
end
BestObj=0;
OF=BestObj;
OF_Relay=BestCost;
TMS=(Pop_Particle(1:length(Ifp),1))
PS=(Pop_Particle(1:length(Ifp),2))

for i=1:length(Ifp)
        BestObj=a*TMS'./((Ifp(i)./(CTr(i).*PS')).^b-1);
        Fitness=BestObj
end
BestObj
%% Results
disp('')
disp('The Objective Function Values is Given By')
% TOP=Fitness'
disp('The Optimum Objective Function Value is Given By')
% OCR=sum(Fitness)
toc
figure;
plot(BestCost,'LineWidth',2);
% semilogy(BestCost,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;
